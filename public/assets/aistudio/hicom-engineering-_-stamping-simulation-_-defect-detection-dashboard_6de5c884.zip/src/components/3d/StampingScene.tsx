/**
 * Interactive 3D Metal Stamping Simulation Environment for HICOM Engineering Sdn Bhd
 * Built with Three.js (r160+ PBR standards, procedural mechanical geometry, RoomEnvironment, and camera controls)
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { StampingPart, PartOperation } from '../../data/partsData';
import { soundEngine } from '../../utils/audioSynthesis';

export type CameraPreset =
  | 'posX'
  | 'negX'
  | 'posY'
  | 'negY'
  | 'posZ'
  | 'negZ'
  | 'top'
  | 'bottom'
  | 'front'
  | 'back'
  | 'right'
  | 'left'
  | 'isometric'
  | 'fit';

interface StampingSceneProps {
  currentPart: StampingPart;
  currentOpIndex: number;
  isPlaying: boolean;
  playbackSpeed: 1 | 2 | 5;
  restartTrigger?: number;
  manualProgressOverride?: number | null; // 0.0 to 1.0 manual scrub
  onCycleComplete: () => void;
  onProgressUpdate: (progress: number, strokeAngle: number, ramDisplacementMm: number, pressureBar: number) => void;
  showGrid: boolean;
  activeCameraPreset: CameraPreset | null;
  onCameraPresetHandled: () => void;
}

export const StampingScene: React.FC<StampingSceneProps> = ({
  currentPart,
  currentOpIndex,
  isPlaying,
  playbackSpeed,
  restartTrigger = 0,
  manualProgressOverride = null,
  onCycleComplete,
  onProgressUpdate,
  showGrid,
  activeCameraPreset,
  onCameraPresetHandled
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // References to Three.js instances to avoid recreation
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);

  // 3D Cartesian Coordinate Gizmo instances
  const axesMountRef = useRef<HTMLDivElement>(null);
  const axesRendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const axesSceneRef = useRef<THREE.Scene | null>(null);
  const axesCameraRef = useRef<THREE.PerspectiveCamera | null>(null);

  // Moving 3D components
  const ramSlideGroupRef = useRef<THREE.Group | null>(null);
  const pistonRodsRef = useRef<THREE.Mesh[]>([]);
  const workpieceGroupRef = useRef<THREE.Group | null>(null);
  const lowerDieGroupRef = useRef<THREE.Group | null>(null);
  const upperDieGroupRef = useRef<THREE.Group | null>(null);
  const scrapParticlesRef = useRef<THREE.Points | null>(null);

  // Camera transition state
  const targetCamPosRef = useRef<THREE.Vector3 | null>(null);
  const targetCamLookRef = useRef<THREE.Vector3 | null>(null);
  const targetCamUpRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 1, 0));

  // Simulation physics & stroke loop state
  const cycleTimeRef = useRef<number>(0);
  const strokeAngleRef = useRef<number>(0); // 0 - 360 deg
  const lastOpIndexRef = useRef<number>(currentOpIndex);
  const hasImpactedInCycleRef = useRef<boolean>(false);

  // Props refs for access inside render loop without re-running mount useEffect
  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;

  const speedRef = useRef(playbackSpeed);
  speedRef.current = playbackSpeed;

  const manualOverrideRef = useRef<number | null>(manualProgressOverride);
  manualOverrideRef.current = manualProgressOverride;

  const currentOpRef = useRef<PartOperation | undefined>(currentPart.operations[currentOpIndex]);
  currentOpRef.current = currentPart.operations[currentOpIndex];

  const partRef = useRef(currentPart);
  partRef.current = currentPart;

  const onCycleCompleteRef = useRef(onCycleComplete);
  onCycleCompleteRef.current = onCycleComplete;

  const onProgressUpdateRef = useRef(onProgressUpdate);
  onProgressUpdateRef.current = onProgressUpdate;

  // Build Procedural Sheet Metal Geometry based on Operation & Part
  const updateWorkpieceGeometry = useCallback((opIndex: number, part: StampingPart, deformationRatio: number = 1.0) => {
    if (!workpieceGroupRef.current) return;
    const group = workpieceGroupRef.current;

    // Clear previous children
    while (group.children.length > 0) {
      const obj = group.children[0];
      group.remove(obj);
      if ((obj as THREE.Mesh).geometry) (obj as THREE.Mesh).geometry.dispose();
    }

    const currentOp = part.operations[opIndex] || part.operations[0];
    const L = Math.max(0.6, (part.lengthMm || 400) / 450);
    const W = Math.max(0.35, (part.widthMm || 200) / 450);
    const H = Math.max(0.15, (part.heightMm || 100) / 350) * deformationRatio;

    // Metallic material with high PBR fidelity
    const sheetMaterial = new THREE.MeshStandardMaterial({
      color: 0x94A3B8,
      metalness: 0.88,
      roughness: 0.28,
      side: THREE.DoubleSide
    });

    const highlightTrimMaterial = new THREE.MeshStandardMaterial({
      color: 0x0754A6,
      metalness: 0.5,
      roughness: 0.4
    });

    if (currentOp.toolingAction === 'blank') {
      // Flat blank sheet with pilot locating holes
      const shape = new THREE.Shape();
      const halfL = L / 2;
      const halfW = W / 2;
      shape.moveTo(-halfL, -halfW);
      shape.lineTo(halfL, -halfW);
      shape.lineTo(halfL + 0.05, 0);
      shape.lineTo(halfL, halfW);
      shape.lineTo(-halfL, halfW);
      shape.lineTo(-halfL - 0.05, 0);
      shape.closePath();

      // Pilot registration holes
      const hole1 = new THREE.Path();
      hole1.absarc(-halfL * 0.7, 0, 0.025, 0, Math.PI * 2, true);
      shape.holes.push(hole1);

      const hole2 = new THREE.Path();
      hole2.absarc(halfL * 0.7, 0, 0.025, 0, Math.PI * 2, true);
      shape.holes.push(hole2);

      const extrudeSettings = { depth: 0.015, bevelEnabled: false };
      const geom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      geom.rotateX(Math.PI / 2);
      const mesh = new THREE.Mesh(geom, sheetMaterial);
      mesh.position.y = 0.01;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
    } else {
      // 3D Stamped Formed Geometry (Draw / Trim / Restrike / Flange)
      const isDrawn = opIndex >= 1;
      const isTrimmed = opIndex >= 2;
      const isRestruck = opIndex >= 3;
      const isPierced = opIndex >= 4 || currentOp.fullName.toLowerCase().includes('pierc');

      const formedGroup = new THREE.Group();

      // Base bottom cavity floor
      const floorGeom = new THREE.BoxGeometry(L * 0.7, 0.015, W * 0.65);
      const floorMesh = new THREE.Mesh(floorGeom, sheetMaterial);
      floorMesh.position.y = -H * 0.4;
      floorMesh.castShadow = true;
      formedGroup.add(floorMesh);

      // Sloped sidewalls (drawn cup / channel)
      const wallThickness = 0.015;
      const wallGeomLong = new THREE.BoxGeometry(L * 0.7, H * 0.5, wallThickness);
      const wallFront = new THREE.Mesh(wallGeomLong, sheetMaterial);
      wallFront.position.set(0, -H * 0.15, W * 0.325);
      wallFront.rotation.x = 0.25;
      formedGroup.add(wallFront);

      const wallBack = new THREE.Mesh(wallGeomLong, sheetMaterial);
      wallBack.position.set(0, -H * 0.15, -W * 0.325);
      wallBack.rotation.x = -0.25;
      formedGroup.add(wallBack);

      const wallGeomSide = new THREE.BoxGeometry(wallThickness, H * 0.5, W * 0.65);
      const wallLeft = new THREE.Mesh(wallGeomSide, sheetMaterial);
      wallLeft.position.set(-L * 0.35, -H * 0.15, 0);
      wallLeft.rotation.z = -0.25;
      formedGroup.add(wallLeft);

      const wallRight = new THREE.Mesh(wallGeomSide, sheetMaterial);
      wallRight.position.set(L * 0.35, -H * 0.15, 0);
      wallRight.rotation.z = 0.25;
      formedGroup.add(wallRight);

      // Outer flanges
      const flangeWidth = isTrimmed ? 0.08 : 0.18; // Trim removes excess addendum
      const flangeGeom = new THREE.BoxGeometry(L * 0.85, 0.015, flangeWidth);
      const flangeFront = new THREE.Mesh(flangeGeom, sheetMaterial);
      flangeFront.position.set(0, 0.05, W * 0.36 + flangeWidth / 2);
      formedGroup.add(flangeFront);

      const flangeBack = new THREE.Mesh(flangeGeom, sheetMaterial);
      flangeBack.position.set(0, 0.05, -(W * 0.36 + flangeWidth / 2));
      formedGroup.add(flangeBack);

      // Flange Upward Bends if OP includes Flanging
      if (currentOp.fullName.toLowerCase().includes('flang') || currentOp.fullName.toLowerCase().includes('bend') || isRestruck) {
        const upFlangeGeom = new THREE.BoxGeometry(L * 0.75, 0.08, 0.015);
        const upFlange = new THREE.Mesh(upFlangeGeom, sheetMaterial);
        upFlange.position.set(0, 0.09, W * 0.36 + flangeWidth);
        formedGroup.add(upFlange);
      }

      // Reinforcing embossed beads (restrike feature)
      if (isRestruck) {
        const beadGeom = new THREE.CylinderGeometry(0.015, 0.015, L * 0.5, 12);
        beadGeom.rotateZ(Math.PI / 2);
        const bead = new THREE.Mesh(beadGeom, sheetMaterial);
        bead.position.set(0, -H * 0.38, 0);
        formedGroup.add(bead);
      }

      // Punched Holes (visible dark cylinders penetrating part)
      if (isPierced) {
        const holePunchGeom = new THREE.CylinderGeometry(0.025, 0.025, 0.03, 16);
        const holeMat = new THREE.MeshBasicMaterial({ color: 0x1E293B });
        
        const holePositions = [
          [-L * 0.25, 0.05, W * 0.4],
          [L * 0.25, 0.05, W * 0.4],
          [-L * 0.25, 0.05, -W * 0.4],
          [L * 0.25, 0.05, -W * 0.4],
          [0, -H * 0.4, 0] // Center drain hole
        ];

        holePositions.forEach(([hx, hy, hz]) => {
          const hole = new THREE.Mesh(holePunchGeom, holeMat);
          hole.position.set(hx, hy, hz);
          formedGroup.add(hole);
        });
      }

      formedGroup.position.y = 0.05;
      group.add(formedGroup);
    }
  }, []);

  // Set camera view preset
  const applyCameraPreset = useCallback((preset: CameraPreset) => {
    if (!cameraRef.current || !controlsRef.current) return;
    const camera = cameraRef.current;
    const controls = controlsRef.current;

    const target = new THREE.Vector3(0, 1.3, 0); // Focus on center of die/ram zone
    const dist = 5.2;

    let targetPos = new THREE.Vector3();
    let targetUp = new THREE.Vector3(0, 1, 0);

    switch (preset) {
      case 'posX':
      case 'right':
        targetPos.set(dist, 1.3, 0);
        targetUp.set(0, 1, 0);
        break;
      case 'negX':
      case 'left':
        targetPos.set(-dist, 1.3, 0);
        targetUp.set(0, 1, 0);
        break;
      case 'posY':
      case 'top':
        targetPos.set(0, dist + 1.3, 0.001); // Slight epsilon to prevent gimbal lock
        targetUp.set(0, 0, -1);
        break;
      case 'negY':
      case 'bottom':
        targetPos.set(0, -dist + 1.3, 0.001);
        targetUp.set(0, 0, 1);
        break;
      case 'posZ':
      case 'front':
        targetPos.set(0, 1.3, dist);
        targetUp.set(0, 1, 0);
        break;
      case 'negZ':
      case 'back':
        targetPos.set(0, 1.3, -dist);
        targetUp.set(0, 1, 0);
        break;
      case 'fit':
      case 'isometric':
      default:
        targetPos.set(3.8, 3.2, 4.2);
        targetUp.set(0, 1, 0);
        break;
    }

    targetCamPosRef.current = targetPos;
    targetCamLookRef.current = target;
    targetCamUpRef.current = targetUp;
    controls.target.copy(target);
  }, []);

  // Handle physical simulation restart when restartTrigger prop changes
  useEffect(() => {
    cycleTimeRef.current = 0;
    strokeAngleRef.current = 0;
    hasImpactedInCycleRef.current = false;
    if (ramSlideGroupRef.current) {
      ramSlideGroupRef.current.position.y = 2.5; // Reset to Top Dead Center (TDC)
    }
    pistonRodsRef.current.forEach((rod) => {
      rod.position.y = (3.1 + 2.5) / 2;
      rod.scale.y = (3.1 - 2.5) / 0.8;
    });
    updateWorkpieceGeometry(currentOpIndex, currentPart, 1.0);
  }, [restartTrigger, currentOpIndex, currentPart, updateWorkpieceGeometry]);

  // Update geometry when part or opIndex changes
  useEffect(() => {
    updateWorkpieceGeometry(currentOpIndex, currentPart, 1.0);
    lastOpIndexRef.current = currentOpIndex;
    strokeAngleRef.current = 0;
    cycleTimeRef.current = 0;
    hasImpactedInCycleRef.current = false;
    if (ramSlideGroupRef.current) {
      ramSlideGroupRef.current.position.y = 2.5;
    }
    pistonRodsRef.current.forEach((rod) => {
      rod.position.y = (3.1 + 2.5) / 2;
      rod.scale.y = (3.1 - 2.5) / 0.8;
    });
  }, [currentPart, currentOpIndex, updateWorkpieceGeometry]);

  // Handle immediate manual progress slider scrub (real-time kinematic position)
  useEffect(() => {
    if (manualProgressOverride !== null && manualProgressOverride !== undefined) {
      const cycleProgress = Math.max(0, Math.min(1, manualProgressOverride));
      cycleTimeRef.current = cycleProgress;
      const strokeAngle = Math.max(0, (cycleProgress * 360) % 360);
      strokeAngleRef.current = strokeAngle;

      const TDC = 2.5;
      const BDC = 1.38;
      const strokeLength = TDC - BDC;
      const angleRad = (strokeAngle * Math.PI) / 180;
      const strokeNormalized = (1 - Math.cos(angleRad)) / 2;
      const ramY = TDC - strokeNormalized * strokeLength;

      if (ramSlideGroupRef.current) {
        ramSlideGroupRef.current.position.y = ramY;
      }

      pistonRodsRef.current.forEach((rod) => {
        rod.position.y = (3.1 + ramY) / 2;
        rod.scale.y = (3.1 - ramY) / 0.8;
      });
    }
  }, [manualProgressOverride]);

  // Handle camera presets requested from parent UI
  useEffect(() => {
    if (activeCameraPreset) {
      applyCameraPreset(activeCameraPreset);
      onCameraPresetHandled();
    }
  }, [activeCameraPreset, applyCameraPreset, onCameraPresetHandled]);

  // Toggle grid visibility
  useEffect(() => {
    if (gridHelperRef.current) {
      gridHelperRef.current.visible = showGrid;
    }
  }, [showGrid]);

  // Initial Scene Setup
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software GL per Three.js skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xF3F5F8);
    scene.fog = new THREE.Fog(0xF3F5F8, 12, 28);
    sceneRef.current = scene;

    // 2. Camera
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 550;
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 50);
    camera.position.set(3.8, 3.2, 4.2);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // 4. OrbitControls with restricted zoom and ground-level orbital limits
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enableRotate = true;
    controls.enableZoom = true;
    controls.enablePan = true;
    controls.screenSpacePanning = true;
    controls.panSpeed = 1.0;
    controls.rotateSpeed = 0.85;
    controls.zoomSpeed = 1.2;
    controls.target.set(0, 1.3, 0);

    // Zoom limits: Prevent zooming out too far while maintaining smooth zoom in/out
    controls.minDistance = 1.8;  // Close enough for detailed inspection of tooling die & part
    controls.maxDistance = 11.0; // Reasonable maximum viewing distance; prevents zooming out into the void

    // Vertical orbit limits: Keep camera strictly above ground level (y >= 0.08) at all times
    // Polar angle: 0 = straight overhead top view; Math.PI / 2 = horizontal horizon at target height
    controls.minPolarAngle = 0.05; // Overhead top view
    controls.maxPolarAngle = Math.PI / 2 - 0.04; // 87.7°: Restricts camera from going below ground plane or viewing from underneath

    controls.mouseButtons = {
      LEFT: THREE.MOUSE.ROTATE,
      MIDDLE: THREE.MOUSE.DOLLY,
      RIGHT: THREE.MOUSE.PAN
    };
    controlsRef.current = controls;

    // 5. Studio Environment Map (PMREMGenerator + RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 6. Lighting Rig (Key, Fill, Rim)
    const keyLight = new THREE.DirectionalLight(0xFFFFFF, 2.2);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 2048;
      keyLight.shadow.mapSize.height = 2048;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 25;
      const d = 4.5;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
    }
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x8DBEFF, 1.0);
    fillLight.position.set(-6, 4, -4);
    scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight(0xFFFFFF, 0x0B2340, 0.7);
    hemiLight.position.set(0, 10, 0);
    scene.add(hemiLight);

    // 7. Ground Foundation & Stationary Base
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0xE2E8F0,
      roughness: 0.8,
      metalness: 0.1
    });
    const groundPlane = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), groundMat);
    groundPlane.rotation.x = -Math.PI / 2;
    groundPlane.position.y = 0;
    groundPlane.receiveShadow = !isSoftwareGl;
    scene.add(groundPlane);

    // Safety boundary marking zone on floor (HICOM safety yellow & black hazard boundary)
    const safetyBorderMat = new THREE.MeshBasicMaterial({ color: 0xF59E0B });
    const safetyBorder = new THREE.Mesh(new THREE.RingGeometry(2.6, 2.7, 32), safetyBorderMat);
    safetyBorder.rotation.x = -Math.PI / 2;
    safetyBorder.position.y = 0.002;
    scene.add(safetyBorder);

    // Ground Grid
    const grid = new THREE.GridHelper(16, 32, 0x0754A6, 0xCBD5E1);
    grid.position.y = 0.003;
    grid.visible = showGrid;
    gridHelperRef.current = grid;
    scene.add(grid);

    // 8. ASSEMBLE PROCEDURAL 3D STAMPING MACHINE
    // Built as a composite hierarchical industrial press (Bed, Upright Columns, Tie Rods, Crown, Moving Ram/Slide, Dies)
    const machineRoot = new THREE.Group();
    machineRoot.name = "StampingMachine_Root";

    // Palette materials
    const bluePaintMat = new THREE.MeshStandardMaterial({
      color: 0x0754A6, // HICOM Brand Blue
      metalness: 0.45,
      roughness: 0.38
    });
    const darkCastMat = new THREE.MeshStandardMaterial({
      color: 0x1E293B, // Heavy cast iron frame
      metalness: 0.6,
      roughness: 0.5
    });
    const chromePillarMat = new THREE.MeshStandardMaterial({
      color: 0xE2E8F0, // Polished chrome guide pillars
      metalness: 0.95,
      roughness: 0.12
    });
    const dieSteelMat = new THREE.MeshStandardMaterial({
      color: 0x334155, // D2 Hardened Tooling Die
      metalness: 0.85,
      roughness: 0.22
    });
    const accentYellowMat = new THREE.MeshStandardMaterial({
      color: 0xEAB308, // Safety yellow accents
      metalness: 0.2,
      roughness: 0.4
    });

    // 8A. Lower Bed & Bolster Plate
    const bedBaseGeom = new THREE.BoxGeometry(2.8, 0.45, 2.2);
    const bedBase = new THREE.Mesh(bedBaseGeom, darkCastMat);
    bedBase.position.set(0, 0.225, 0);
    bedBase.castShadow = true;
    bedBase.receiveShadow = true;
    machineRoot.add(bedBase);

    // Bolster plate with T-slots
    const bolsterGeom = new THREE.BoxGeometry(2.4, 0.22, 1.8);
    const bolster = new THREE.Mesh(bolsterGeom, dieSteelMat);
    bolster.position.set(0, 0.56, 0);
    bolster.castShadow = true;
    bolster.receiveShadow = true;
    machineRoot.add(bolster);

    // Lower Tooling Die Block
    const lowerDieGroup = new THREE.Group();
    lowerDieGroup.position.set(0, 0.67, 0);
    const lowerDieShoe = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.18, 1.2), darkCastMat);
    lowerDieShoe.position.y = 0.09;
    lowerDieGroup.add(lowerDieShoe);

    const lowerDieCavity = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.14, 0.8), dieSteelMat);
    lowerDieCavity.position.y = 0.25;
    lowerDieCavity.castShadow = true;
    lowerDieGroup.add(lowerDieCavity);

    // Locating pins on lower die
    const pinGeom = new THREE.CylinderGeometry(0.02, 0.02, 0.08, 12);
    const pin1 = new THREE.Mesh(pinGeom, chromePillarMat);
    pin1.position.set(-0.55, 0.36, -0.35);
    const pin2 = new THREE.Mesh(pinGeom, chromePillarMat);
    pin2.position.set(0.55, 0.36, -0.35);
    lowerDieGroup.add(pin1, pin2);

    lowerDieGroupRef.current = lowerDieGroup;
    machineRoot.add(lowerDieGroup);

    // 8B. Four Upright Guide Columns (Pillars & Gibs)
    const pillarGeom = new THREE.CylinderGeometry(0.09, 0.09, 2.8, 24);
    const pillarPositions = [
      [-1.15, 1.95, -0.85],
      [1.15, 1.95, -0.85],
      [-1.15, 1.95, 0.85],
      [1.15, 1.95, 0.85]
    ];
    pillarPositions.forEach(([px, py, pz]) => {
      const pillar = new THREE.Mesh(pillarGeom, chromePillarMat);
      pillar.position.set(px, py, pz);
      pillar.castShadow = true;
      machineRoot.add(pillar);

      // Heavy tie-rod nuts at top and bottom
      const nutGeom = new THREE.CylinderGeometry(0.13, 0.13, 0.12, 6);
      const topNut = new THREE.Mesh(nutGeom, darkCastMat);
      topNut.position.set(px, 3.4, pz);
      const botNut = new THREE.Mesh(nutGeom, darkCastMat);
      botNut.position.set(px, 0.5, pz);
      machineRoot.add(topNut, botNut);
    });

    // Side frame upright housings
    const sideColumnGeom = new THREE.BoxGeometry(0.4, 2.6, 1.6);
    const leftSideCol = new THREE.Mesh(sideColumnGeom, bluePaintMat);
    leftSideCol.position.set(-1.25, 1.95, 0);
    leftSideCol.castShadow = true;
    const rightSideCol = new THREE.Mesh(sideColumnGeom, bluePaintMat);
    rightSideCol.position.set(1.25, 1.95, 0);
    rightSideCol.castShadow = true;
    machineRoot.add(leftSideCol, rightSideCol);

    // 8C. Top Crown (Flywheel, Motor, Hydraulic Cylinders)
    const crownGeom = new THREE.BoxGeometry(2.9, 0.9, 2.3);
    const crown = new THREE.Mesh(crownGeom, bluePaintMat);
    crown.position.set(0, 3.75, 0);
    crown.castShadow = true;
    machineRoot.add(crown);

    // Crown maintenance platform & handrails
    const railMat = new THREE.MeshBasicMaterial({ color: 0xEAB308 });
    const railTop = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.03, 2.1), railMat);
    railTop.position.set(0, 4.25, 0);
    machineRoot.add(railTop);

    // Motor housing on top crown
    const motorGeom = new THREE.CylinderGeometry(0.35, 0.35, 0.7, 24);
    motorGeom.rotateZ(Math.PI / 2);
    const motor = new THREE.Mesh(motorGeom, darkCastMat);
    motor.position.set(0, 4.45, -0.4);
    machineRoot.add(motor);

    // Main Flywheel
    const flywheelGeom = new THREE.CylinderGeometry(0.55, 0.55, 0.18, 32);
    flywheelGeom.rotateZ(Math.PI / 2);
    const flywheel = new THREE.Mesh(flywheelGeom, darkCastMat);
    flywheel.position.set(1.5, 4.45, -0.4);
    machineRoot.add(flywheel);

    // 8D. Hydraulic Main Cylinders (Mounted under Crown)
    const cylPositions = [[-0.45, 0], [0.45, 0]];
    const pistonRods: THREE.Mesh[] = [];

    cylPositions.forEach(([cx, cz]) => {
      // Cylinder barrel
      const barrelGeom = new THREE.CylinderGeometry(0.18, 0.18, 0.8, 20);
      const barrel = new THREE.Mesh(barrelGeom, darkCastMat);
      barrel.position.set(cx, 3.1, cz);
      machineRoot.add(barrel);

      // Extending chrome piston rod
      const rodGeom = new THREE.CylinderGeometry(0.08, 0.08, 1.1, 20);
      const rod = new THREE.Mesh(rodGeom, chromePillarMat);
      rod.position.set(cx, 2.4, cz);
      machineRoot.add(rod);
      pistonRods.push(rod);
    });
    pistonRodsRef.current = pistonRods;

    // 8E. MOVING UPPER SLIDE / RAM & UPPER DIE
    const ramSlideGroup = new THREE.Group();
    ramSlideGroup.name = "RamSlide_Assembly";
    ramSlideGroup.position.set(0, 2.5, 0); // Initial Top Dead Center (TDC)

    // Ram slide body
    const ramBodyGeom = new THREE.BoxGeometry(2.1, 0.5, 1.5);
    const ramBody = new THREE.Mesh(ramBodyGeom, bluePaintMat);
    ramBody.castShadow = true;
    ramSlideGroup.add(ramBody);

    // Slide guide bushings (sleeves sliding on 4 corner pillars)
    pillarPositions.forEach(([px, _, pz]) => {
      const sleeveGeom = new THREE.CylinderGeometry(0.13, 0.13, 0.52, 16);
      const sleeve = new THREE.Mesh(sleeveGeom, darkCastMat);
      sleeve.position.set(px, 0, pz);
      ramSlideGroup.add(sleeve);
    });

    // Upper Die Holder / Punch Tool
    const upperDieGroup = new THREE.Group();
    upperDieGroup.position.set(0, -0.32, 0);

    const upperDieShoe = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.14, 1.1), darkCastMat);
    upperDieGroup.add(upperDieShoe);

    const punchPunch = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.22, 0.75), dieSteelMat);
    punchPunch.position.y = -0.16;
    punchPunch.castShadow = true;
    upperDieGroup.add(punchPunch);

    upperDieGroupRef.current = upperDieGroup;
    ramSlideGroup.add(upperDieGroup);

    ramSlideGroupRef.current = ramSlideGroup;
    machineRoot.add(ramSlideGroup);

    // 8F. Workpiece Group (Placed between Upper and Lower Die)
    const workpieceGroup = new THREE.Group();
    workpieceGroup.name = "Workpiece_SheetMetal";
    workpieceGroup.position.set(0, 1.0, 0); // Resting on top of lower die cavity (y = 0.67 + 0.32 = ~1.0)
    workpieceGroupRef.current = workpieceGroup;
    machineRoot.add(workpieceGroup);

    // 8G. Safety Light Curtains (Optical Safety Sensors)
    const sensorPostGeom = new THREE.CylinderGeometry(0.03, 0.03, 1.6, 12);
    const lightCurtainMat = new THREE.MeshBasicMaterial({ color: 0x10B981 }); // Green safe status
    const leftSensor = new THREE.Mesh(sensorPostGeom, accentYellowMat);
    leftSensor.position.set(-1.0, 1.45, 1.05);
    const rightSensor = new THREE.Mesh(sensorPostGeom, accentYellowMat);
    rightSensor.position.set(1.0, 1.45, 1.05);
    machineRoot.add(leftSensor, rightSensor);

    // Operator Control Console Pedestal
    const consolePost = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.0, 12), darkCastMat);
    consolePost.position.set(1.5, 0.5, 1.3);
    const consoleHead = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.25, 0.2), bluePaintMat);
    consoleHead.position.set(1.5, 1.1, 1.3);
    consoleHead.rotation.x = -0.3;
    const estopButton = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.04, 12), new THREE.MeshBasicMaterial({ color: 0xEF4444 }));
    estopButton.position.set(1.6, 1.15, 1.35);
    machineRoot.add(consolePost, consoleHead, estopButton);

    scene.add(machineRoot);

    // Pre-warm shaders
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Initialize initial geometry
    updateWorkpieceGeometry(currentOpIndex, currentPart, 1.0);

    // 9. ANIMATION & RENDER LOOP
    let animationFrameId: number;
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      animationFrameId = requestAnimationFrame(animate);

      if (isSoftwareGl && currentTime - lastTime < 33) {
        return; // Throttle to ~30 FPS on software CPU WebGL to leave event loop cycles free
      }

      const delta = Math.min(0.05, (currentTime - lastTime) / 1000);
      lastTime = currentTime;

      // Handle Smooth Camera Preset Transition
      if (targetCamPosRef.current && targetCamLookRef.current) {
        camera.position.lerp(targetCamPosRef.current, 0.08);
        controls.target.lerp(targetCamLookRef.current, 0.08);
        camera.up.lerp(targetCamUpRef.current, 0.08);

        if (camera.position.distanceTo(targetCamPosRef.current) < 0.02) {
          targetCamPosRef.current = null;
          targetCamLookRef.current = null;
        }
      }

      controls.update();

      // Enforce ground boundary: ensure camera eye level never penetrates below the floor plane (y >= 0.08)
      if (camera.position.y < 0.08) {
        camera.position.y = 0.08;
      }

      // Kinematic Simulation of Stamping Cycle
      // TDC (Top Dead Center): y = 2.5
      // BDC (Bottom Dead Center / Impact Point): y = 1.38
      const TDC = 2.5;
      const BDC = 1.38;
      const strokeLength = TDC - BDC;

      if (isPlayingRef.current) {
        // Crank Cycle Frequency (e.g. 20-30 Strokes Per Minute scaled by playbackSpeed)
        const baseCycleDurationSec = 2.5; // 24 SPM at 1x
        const currentSpeed = speedRef.current;
        const progressIncrement = delta / (baseCycleDurationSec / currentSpeed);

        cycleTimeRef.current = (cycleTimeRef.current + progressIncrement) % 1.0;
        const cycleProgress = Math.max(0, cycleTimeRef.current);
        const strokeAngle = Math.max(0, (cycleProgress * 360) % 360);
        strokeAngleRef.current = strokeAngle;

        // Harmonic mechanical press stroke displacement curve
        // Angle 0 deg = TDC, 180 deg = BDC, 360 deg = TDC
        const angleRad = (strokeAngle * Math.PI) / 180;
        // Position: 0 at TDC, 1 at BDC: (1 - cos(angleRad)) / 2
        const strokeNormalized = (1 - Math.cos(angleRad)) / 2;
        const ramY = TDC - strokeNormalized * strokeLength;

        if (ramSlideGroupRef.current) {
          ramSlideGroupRef.current.position.y = ramY;
        }

        // Update hydraulic piston rods to track slide
        pistonRodsRef.current.forEach((rod) => {
          rod.position.y = (3.1 + ramY) / 2;
          rod.scale.y = (3.1 - ramY) / 0.8;
        });

        // Trigger deformation and impact audio at Bottom Dead Center (around 170° - 190°)
        if (strokeAngle >= 170 && strokeAngle <= 190 && !hasImpactedInCycleRef.current) {
          hasImpactedInCycleRef.current = true;
          const tonnage = currentOpRef.current?.pressTonnage || 300;
          soundEngine.playStampImpact(tonnage);
        }

        // Reset impact trigger and play return hydraulic release
        if (strokeAngle > 220 && hasImpactedInCycleRef.current) {
          hasImpactedInCycleRef.current = false;
          soundEngine.playHydraulicRelease();
        }

        // Live calculation of technical telemetry
        // Pressure rises exponentially during final 30 degrees approaching BDC
        let pressPressureBar = 12.0; // Baseline hydraulic preload
        if (strokeAngle >= 140 && strokeAngle <= 210) {
          const contactProgress = Math.sin(((strokeAngle - 140) / 70) * Math.PI);
          const maxTonnage = currentOpRef.current?.pressTonnage || 400;
          const maxBar = Math.min(320, 160 + (maxTonnage / 1300) * 150);
          pressPressureBar = 12.0 + contactProgress * maxBar;
        }

        const ramDisplacementMm = strokeNormalized * 350; // 350mm stroke

        onProgressUpdateRef.current(cycleProgress, strokeAngle, ramDisplacementMm, pressPressureBar);

        // Detect full cycle completion to advance operation or loop
        if (cycleProgress < progressIncrement) {
          onCycleCompleteRef.current();
        }
      }

      renderer.render(scene, camera);

      // Render 3D Cartesian Coordinate Axes (dynamically syncing camera orientation)
      if (axesRendererRef.current && axesSceneRef.current && axesCameraRef.current) {
        const axesCam = axesCameraRef.current;
        // Position axes camera at identical orientation vector offset
        const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
        axesCam.position.copy(dir.multiplyScalar(4.0));
        axesCam.lookAt(0, 0, 0);
        axesCam.up.copy(camera.up);
        axesCam.updateProjectionMatrix();

        axesRendererRef.current.render(axesSceneRef.current, axesCam);
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    // Cancel automatic camera lerp as soon as user touches, drags, or scrolls the canvas
    const cancelLerp = () => {
      targetCamPosRef.current = null;
      targetCamLookRef.current = null;
    };

    controls.addEventListener('start', cancelLerp);

    // Also attach pointerdown, mousedown, and wheel listeners to canvas element
    const canvasDom = renderer.domElement;
    canvasDom.style.touchAction = 'none';
    canvasDom.addEventListener('pointerdown', cancelLerp, { passive: true });
    canvasDom.addEventListener('mousedown', cancelLerp, { passive: true });
    canvasDom.addEventListener('wheel', cancelLerp, { passive: true });
    canvasDom.addEventListener('touchstart', cancelLerp, { passive: true });

    // 10. SETUP 3D CARTESIAN COORDINATE AXES INSET (X=Red, Y=Green, Z=Blue)
    const axesContainer = axesMountRef.current;
    if (axesContainer) {
      const axesScene = new THREE.Scene();
      axesSceneRef.current = axesScene;

      const axesCamera = new THREE.PerspectiveCamera(45, 1, 0.1, 20);
      axesCameraRef.current = axesCamera;

      const axesRenderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance'
      });
      axesRenderer.setSize(96, 96);
      axesRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      axesRenderer.outputColorSpace = THREE.SRGBColorSpace;
      axesRendererRef.current = axesRenderer;
      axesContainer.appendChild(axesRenderer.domElement);

      // Ambient & directional lighting for the 3D axes arrows
      const axesAmbLight = new THREE.AmbientLight(0xffffff, 1.2);
      axesScene.add(axesAmbLight);
      const axesDirLight = new THREE.DirectionalLight(0xffffff, 2.0);
      axesDirLight.position.set(3, 4, 3);
      axesScene.add(axesDirLight);

      // Helper function to create a clean axis cylinder + arrow cone (no text labels, dots, or markers)
      const createAxis = (
        direction: THREE.Vector3,
        colorHex: number
      ) => {
        const axisGroup = new THREE.Group();
        const length = 1.45;
        const radius = 0.055;
        const headLength = 0.42;
        const headRadius = 0.14;

        const mat = new THREE.MeshStandardMaterial({
          color: colorHex,
          roughness: 0.3,
          metalness: 0.25
        });

        // Shaft cylinder
        const cylinderGeom = new THREE.CylinderGeometry(radius, radius, length - headLength, 16);
        cylinderGeom.translate(0, (length - headLength) / 2, 0);
        const cylinder = new THREE.Mesh(cylinderGeom, mat);

        // Arrow tip cone
        const coneGeom = new THREE.ConeGeometry(headRadius, headLength, 16);
        coneGeom.translate(0, length - headLength / 2, 0);
        const cone = new THREE.Mesh(coneGeom, mat);

        axisGroup.add(cylinder, cone);

        // Orient axis along direction vector
        const up = new THREE.Vector3(0, 1, 0);
        if (!up.equals(direction)) {
          if (up.clone().negate().equals(direction)) {
            axisGroup.rotation.x = Math.PI;
          } else {
            const quat = new THREE.Quaternion().setFromUnitVectors(up, direction);
            axisGroup.applyQuaternion(quat);
          }
        }

        return axisGroup;
      };

      // X Axis (Red) -> +X
      axesScene.add(createAxis(new THREE.Vector3(1, 0, 0), 0xEF4444));
      // Y Axis (Green) -> +Y
      axesScene.add(createAxis(new THREE.Vector3(0, 1, 0), 0x10B981));
      // Z Axis (Blue) -> +Z
      axesScene.add(createAxis(new THREE.Vector3(0, 0, 1), 0x0754A6));

      // Clean central joint sphere
      const centerSphere = new THREE.Mesh(
        new THREE.SphereGeometry(0.08, 16, 16),
        new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4 })
      );
      axesScene.add(centerSphere);
    }

    // Handle Window Resize
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      controls.removeEventListener('start', cancelLerp);
      canvasDom.removeEventListener('pointerdown', cancelLerp);
      canvasDom.removeEventListener('mousedown', cancelLerp);
      canvasDom.removeEventListener('wheel', cancelLerp);
      canvasDom.removeEventListener('touchstart', cancelLerp);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (rendererRef.current && rendererRef.current.domElement) {
        container.removeChild(rendererRef.current.domElement);
        rendererRef.current.dispose();
      }
      if (axesRendererRef.current && axesRendererRef.current.domElement && axesMountRef.current) {
        axesMountRef.current.removeChild(axesRendererRef.current.domElement);
        axesRendererRef.current.dispose();
      }
    };
  }, []); // Run ONCE on mount so canvas, WebGL context, and OrbitControls are never unmounted or reset during playback

  return (
    <div className="relative w-full h-full min-h-[480px] bg-[#F3F5F8] select-none overflow-hidden rounded-xl border border-[#E2E8F0] shadow-inner">
      {/* Three.js Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Viewport Top Watermark / Status Badge */}
      <div className="absolute top-3 left-3 flex items-center gap-2 bg-[#FFFFFF]/90 border border-[#E2E8F0] px-3 py-1.5 rounded-lg shadow-sm backdrop-blur-none pointer-events-none">
        <div className="w-2.5 h-2.5 rounded-full bg-[#0754A6]" />
        <span className="text-xs font-semibold text-[#0B2340] tracking-wide uppercase">
          3D Hydraulic Stamping Press Sim
        </span>
        <span className="text-[11px] text-[#64748B] font-mono border-l border-[#CBD5E1] pl-2">
          {currentPart.devType} ({currentPart.pressLineSummary})
        </span>
      </div>

      {/* 3D Cartesian Coordinate Axes (X=Red, Y=Green, Z=Blue) directly on viewport without box, border, or text */}
      <div
        ref={axesMountRef}
        className="absolute top-2 right-2 w-[84px] h-[84px] pointer-events-none flex items-center justify-center overflow-hidden"
        title="3D Cartesian Coordinate Axes (X: Red, Y: Green, Z: Blue)"
      />
    </div>
  );
};
