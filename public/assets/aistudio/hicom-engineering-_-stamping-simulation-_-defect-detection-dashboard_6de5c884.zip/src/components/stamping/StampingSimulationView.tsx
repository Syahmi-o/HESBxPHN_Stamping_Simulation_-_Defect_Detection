/**
 * HICOM Engineering Sdn Bhd - Stamping Simulation View
 * Features:
 * - 43 Automotive Parts selection with accurate process plans
 * - Interactive 3D Three.js mechanical stamping press simulation
 * - 14 Comprehensive camera views (+X, -X, +Y, -Y, +Z, -Z, Top, Bottom, Front, Back, Right, Left, Fit, Reset)
 * - Complete simulation controls (Play, Pause, Restart, Skip, 1x/2x/5x, Prev/Next)
 * - Real-time technical telemetry panel ([SIMULATED] vs [TELEMETRY] indicators)
 * - Detailed part technical specifications card
 */

import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Grid,
  Volume2,
  VolumeX,
  Search,
  Filter,
  Layers,
  Gauge,
  Thermometer,
  Activity,
  Compass,
  Sliders,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';
import { StampingScene, CameraPreset } from '../3d/StampingScene';
import { STAMPING_PARTS, StampingPart } from '../../data/partsData';
import { soundEngine } from '../../utils/audioSynthesis';

export const StampingSimulationView: React.FC = () => {
  // Part Selection State
  const [selectedPartId, setSelectedPartId] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [lineFilter, setLineFilter] = useState<'ALL' | 'ML' | 'SL'>('ALL');
  const [diesFilter, setDiesFilter] = useState<'ALL' | 'CAST' | 'STEEL'>('ALL');

  // Simulation Playback State
  const [currentOpIndex, setCurrentOpIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false); // Don't automatically start until play is pressed
  const [playbackSpeed, setPlaybackSpeed] = useState<1 | 2 | 5>(1);
  const [restartTrigger, setRestartTrigger] = useState<number>(0);
  const [manualProgressOverride, setManualProgressOverride] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Direct Numeric Input Dialog/Popover State
  const [isEditingAngle, setIsEditingAngle] = useState<boolean>(false);
  const [inputAngleValue, setInputAngleValue] = useState<string>('0');
  const [isEditingPercent, setIsEditingPercent] = useState<boolean>(false);
  const [inputPercentValue, setInputPercentValue] = useState<string>('0');

  // 3D Viewport Controls
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [activeCameraPreset, setActiveCameraPreset] = useState<CameraPreset | null>(null);
  const [activeCameraLabel, setActiveCameraLabel] = useState<string>('');

  // Live Telemetry from 3D Scene
  const [simProgress, setSimProgress] = useState<number>(0);
  const [strokeAngle, setStrokeAngle] = useState<number>(0);
  const [ramDisplacementMm, setRamDisplacementMm] = useState<number>(0);
  const [pressPressureBar, setPressPressureBar] = useState<number>(12);

  // Active Part Object
  const currentPart: StampingPart = useMemo(() => {
    return STAMPING_PARTS.find(p => p.id === selectedPartId) || STAMPING_PARTS[0];
  }, [selectedPartId]);

  // Filtered Parts List for selection
  const filteredParts = useMemo(() => {
    return STAMPING_PARTS.filter(p => {
      const matchSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.codeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.partNumber.toLowerCase().includes(searchQuery.toLowerCase());
      const matchLine = lineFilter === 'ALL' || p.devTypeCode === lineFilter;
      const matchDies = diesFilter === 'ALL' || p.diesTypeCode === diesFilter;
      return matchSearch && matchLine && matchDies;
    });
  }, [searchQuery, lineFilter, diesFilter]);

  // Current Operation
  const currentOperation = currentPart.operations[currentOpIndex] || currentPart.operations[0];
  const totalOperations = currentPart.operations.length;

  // Handlers
  const handlePartSelect = (partId: number) => {
    setSelectedPartId(partId);
    setCurrentOpIndex(0);
    setSimProgress(0);
    setStrokeAngle(0);
    setRamDisplacementMm(0);
    setPressPressureBar(12);
    setRestartTrigger(prev => prev + 1);
    setIsPlaying(false); // User requested: Don't automatically start the operation until play simulation button is pressed
  };

  const handleNextOp = () => {
    if (currentOpIndex < totalOperations - 1) {
      setCurrentOpIndex(prev => prev + 1);
      setSimProgress(0);
      setStrokeAngle(0);
      setRamDisplacementMm(0);
      setPressPressureBar(12);
      setRestartTrigger(prev => prev + 1);
      setIsPlaying(false);
    }
  };

  const handlePrevOp = () => {
    if (currentOpIndex > 0) {
      setCurrentOpIndex(prev => prev - 1);
      setSimProgress(0);
      setStrokeAngle(0);
      setRamDisplacementMm(0);
      setPressPressureBar(12);
      setRestartTrigger(prev => prev + 1);
      setIsPlaying(false);
    }
  };

  const handleCycleComplete = () => {
    // If running in continuous loop or multi-operation progression
    // Let's loop the current operation smoothly or prompt next
  };

  // Throttled live telemetry updates to keep React renders at 15-20 fps and never choke OrbitControls or 60fps WebGL
  const lastUpdateRef = React.useRef<number>(0);
  const isDraggingSliderRef = React.useRef<boolean>(false);
  const handleProgressUpdate = (
    progress: number,
    angle: number,
    dispMm: number,
    pressure: number
  ) => {
    // If the user is actively dragging the slider, don't let animation loop overwrite user interaction
    if (isDraggingSliderRef.current) return;
    const now = performance.now();
    if (now - lastUpdateRef.current > 48) { // ~20fps for telemetry cards is instantaneous and smooth
      lastUpdateRef.current = now;
      setSimProgress(progress);
      setStrokeAngle(angle);
      setRamDisplacementMm(dispMm);
      setPressPressureBar(pressure);
    }
  };

  // Manual Adjustment Handlers for interactive stroke slider & direct inputs
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    const progress = Math.max(0, Math.min(1, val / 100));
    setManualProgressOverride(progress);
    setSimProgress(progress);
    const angle = (progress * 360) % 360;
    setStrokeAngle(angle);

    // Compute stroke displacement
    const angleRad = (angle * Math.PI) / 180;
    const strokeNormalized = (1 - Math.cos(angleRad)) / 2;
    setRamDisplacementMm(strokeNormalized * 350);

    // Compute pressure bar
    let pressure = 12.0;
    if (angle >= 140 && angle <= 210) {
      const contactProgress = Math.sin(((angle - 140) / 70) * Math.PI);
      const maxTonnage = currentOperation?.pressTonnage || 400;
      const maxBar = Math.min(320, 160 + (maxTonnage / 1300) * 150);
      pressure = 12.0 + contactProgress * maxBar;
    }
    setPressPressureBar(pressure);
  };

  const handleSliderCommit = () => {
    isDraggingSliderRef.current = false;
  };

  const handlePercentSubmit = () => {
    const num = parseFloat(inputPercentValue);
    if (!isNaN(num)) {
      const clamped = Math.max(0, Math.min(100, num));
      const progress = clamped / 100;
      setManualProgressOverride(progress);
      setSimProgress(progress);
      const angle = (progress * 360) % 360;
      setStrokeAngle(angle);
      const angleRad = (angle * Math.PI) / 180;
      const strokeNormalized = (1 - Math.cos(angleRad)) / 2;
      setRamDisplacementMm(strokeNormalized * 350);

      let pressure = 12.0;
      if (angle >= 140 && angle <= 210) {
        const contactProgress = Math.sin(((angle - 140) / 70) * Math.PI);
        const maxTonnage = currentOperation?.pressTonnage || 400;
        const maxBar = Math.min(320, 160 + (maxTonnage / 1300) * 150);
        pressure = 12.0 + contactProgress * maxBar;
      }
      setPressPressureBar(pressure);
    }
    setIsEditingPercent(false);
  };

  const handleAngleSubmit = () => {
    const num = parseFloat(inputAngleValue);
    if (!isNaN(num)) {
      const clamped = Math.max(0, Math.min(360, num));
      const progress = clamped / 360;
      setManualProgressOverride(progress);
      setSimProgress(progress);
      setStrokeAngle(clamped);
      const angleRad = (clamped * Math.PI) / 180;
      const strokeNormalized = (1 - Math.cos(angleRad)) / 2;
      setRamDisplacementMm(strokeNormalized * 350);

      let pressure = 12.0;
      if (clamped >= 140 && clamped <= 210) {
        const contactProgress = Math.sin(((clamped - 140) / 70) * Math.PI);
        const maxTonnage = currentOperation?.pressTonnage || 400;
        const maxBar = Math.min(320, 160 + (maxTonnage / 1300) * 150);
        pressure = 12.0 + contactProgress * maxBar;
      }
      setPressPressureBar(pressure);
    }
    setIsEditingAngle(false);
  };

  const handleRestart = () => {
    setManualProgressOverride(null);
    setSimProgress(0);
    setStrokeAngle(0);
    setRamDisplacementMm(0);
    setPressPressureBar(12);
    // Reset both the physical 3D simulation and the progress/angle bar, keeping simulation paused at 0%
    setRestartTrigger(prev => prev + 1);
    setIsPlaying(false);
  };

  const handleSkip45 = () => {
    // Current angle clamped between 0 and 360
    const currentAngle = Math.max(0, Math.min(360, strokeAngle));
    const nextAngle = Math.min(360, currentAngle + 45);
    const nextProgress = nextAngle / 360;

    setManualProgressOverride(nextProgress);
    setSimProgress(nextProgress);
    setStrokeAngle(nextAngle);

    // Compute stroke displacement for 350mm stroke
    const angleRad = (nextAngle * Math.PI) / 180;
    const strokeNormalized = (1 - Math.cos(angleRad)) / 2;
    setRamDisplacementMm(strokeNormalized * 350);

    // Compute pressure bar
    let pressure = 12.0;
    if (nextAngle >= 140 && nextAngle <= 210) {
      const contactProgress = Math.sin(((nextAngle - 140) / 70) * Math.PI);
      const maxTonnage = currentOperation?.pressTonnage || 400;
      const maxBar = Math.min(320, 160 + (maxTonnage / 1300) * 150);
      pressure = 12.0 + contactProgress * maxBar;
    }
    setPressPressureBar(pressure);
  };

  const triggerCameraPreset = (preset: CameraPreset, label: string) => {
    setActiveCameraPreset(preset);
    setActiveCameraLabel(label);
  };

  const toggleSound = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundEngine.setMuted(nextMuted);
  };

  // Base SPM calculation according to press line & tonnage
  const baseSpm = currentPart.devTypeCode === 'SL' ? 28 : 18;
  const liveSpm = isPlaying ? baseSpm * playbackSpeed : 0;
  const operatingTempC = (38.5 + (pressPressureBar / 320) * 8.5).toFixed(1);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Top Banner & Part Quick Selector */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Part Selection Header */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#0754A6]/10 flex items-center justify-center text-[#0754A6] shrink-0 font-bold">
              #{currentPart.id}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-[#0754A6]/10 text-[#0754A6]">
                  {currentPart.devType} ({currentPart.devTypeCode})
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#F3F5F8] text-[#64748B] border border-[#E2E8F0]">
                  {currentPart.diesType}
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#F3F5F8] text-[#64748B] border border-[#E2E8F0]">
                  Line: {currentPart.pressLineSummary}
                </span>
              </div>
              <h2 className="text-lg font-bold text-[#0B2340] tracking-tight mt-0.5">
                {currentPart.name}
              </h2>
            </div>
          </div>

          {/* Quick Select Dropdown with Search */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="relative min-w-[280px] sm:min-w-[340px]">
              <select
                aria-label="Select Stamping Part"
                value={selectedPartId}
                onChange={(e) => handlePartSelect(Number(e.target.value))}
                className="w-full bg-[#F3F5F8] border border-[#CBD5E1] text-[#273444] text-xs font-medium rounded-lg px-3 py-2.5 pr-8 appearance-none focus:outline-none focus:ring-2 focus:ring-[#0754A6] focus:border-transparent cursor-pointer font-sans"
              >
                {STAMPING_PARTS.map((part) => (
                  <option key={part.id} value={part.id}>
                    {part.codeName}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-3 pointer-events-none text-[#64748B]">
                <Layers className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main 2-Column Grid: 3D Simulation Viewport + Side Specs & Telemetry */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
        {/* Left Column (8 cols): 3D Viewport & Simulation Controls */}
        <div className="xl:col-span-8 flex flex-col gap-4">
          {/* 3D Viewport Box */}
          <div className="relative w-full h-[520px] bg-white rounded-xl border border-[#E2E8F0] shadow-sm overflow-hidden p-1.5 flex flex-col">
            <StampingScene
              currentPart={currentPart}
              currentOpIndex={currentOpIndex}
              isPlaying={isPlaying}
              playbackSpeed={playbackSpeed}
              restartTrigger={restartTrigger}
              manualProgressOverride={manualProgressOverride}
              onCycleComplete={handleCycleComplete}
              onProgressUpdate={handleProgressUpdate}
              showGrid={showGrid}
              activeCameraPreset={activeCameraPreset}
              onCameraPresetHandled={() => setActiveCameraPreset(null)}
            />

            {/* Camera Views Bar (Front, Side, Fit, Grid, Sound) */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-[#FFFFFF]/95 border border-[#E2E8F0] px-3 py-1.5 rounded-xl shadow-md max-w-[96%] overflow-x-auto text-[11px] font-medium text-[#273444] z-10 backdrop-blur-none">
              <span className="text-[10px] uppercase font-bold text-[#64748B] px-1.5 flex items-center gap-1 whitespace-nowrap">
                <Compass className="w-3.5 h-3.5 text-[#0754A6]" /> Views:
              </span>

              {/* Front and Side views requested by user */}
              <button
                onClick={() => triggerCameraPreset('front', 'Front View')}
                className={`px-3 py-1 rounded hover:bg-[#F3F5F8] transition-colors font-semibold ${activeCameraLabel === 'Front View' ? 'bg-[#0754A6] text-white shadow-xs' : ''}`}
                title="Front view (positive Z elevation)"
              >
                Front
              </button>
              <button
                onClick={() => triggerCameraPreset('right', 'Side View')}
                className={`px-3 py-1 rounded hover:bg-[#F3F5F8] transition-colors font-semibold ${activeCameraLabel === 'Side View' ? 'bg-[#0754A6] text-white shadow-xs' : ''}`}
                title="Side view (right side elevation)"
              >
                Side
              </button>

              <div className="w-[1px] h-4 bg-[#CBD5E1] mx-1 shrink-0" />

              {/* Action tools */}
              <button
                onClick={() => triggerCameraPreset('fit', 'Fit to Screen')}
                className="px-2.5 py-1 rounded hover:bg-[#F3F5F8] text-[#0754A6] font-semibold flex items-center gap-1 shrink-0"
                title="Fit to Screen & Reset Isometric Orbit"
              >
                <Maximize2 className="w-3.5 h-3.5" /> Fit
              </button>
              <button
                onClick={() => setShowGrid(prev => !prev)}
                className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 shrink-0 ${showGrid ? 'bg-[#0754A6]/10 text-[#0754A6]' : 'text-[#64748B]'}`}
                title="Toggle Ground Plane Grid"
              >
                <Grid className="w-3.5 h-3.5" /> {showGrid ? 'Grid On' : 'Grid Off'}
              </button>
              <button
                onClick={toggleSound}
                className={`px-2 py-1 rounded transition-colors shrink-0 ${!isMuted ? 'text-[#0754A6]' : 'text-[#64748B]'}`}
                title={isMuted ? 'Unmute Mechanical Sound' : 'Mute Mechanical Sound'}
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Ergonomic Unified Simulation Controls Dock */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm flex flex-col gap-3">
            {/* Top row: Operation Title & Step Indicator */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E2E8F0] pb-3">
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-md bg-[#0B2340] text-white font-mono text-xs font-bold">
                  {currentOperation.opCode}
                </span>
                <div>
                  <div className="text-sm font-bold text-[#0B2340]">
                    {currentOperation.fullName}
                  </div>
                  <div className="text-xs text-[#64748B]">
                    {currentOperation.description}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <span className="text-xs font-mono font-medium text-[#64748B]">
                  Operation <strong className="text-[#0754A6]">{currentOpIndex + 1}</strong> of <strong>{totalOperations}</strong>
                </span>
                <div className="flex items-center gap-1 bg-[#F3F5F8] p-1 rounded-lg border border-[#E2E8F0]">
                  <button
                    onClick={handlePrevOp}
                    disabled={currentOpIndex === 0}
                    className="p-1 rounded hover:bg-white text-[#273444] disabled:opacity-30 disabled:cursor-not-allowed"
                    title="Previous Operation"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNextOp}
                    disabled={currentOpIndex === totalOperations - 1}
                    className="p-1 rounded hover:bg-white text-[#273444] disabled:opacity-30 disabled:cursor-not-allowed"
                    title="Next Operation"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom Row: Control Buttons + Progress Bar + Speed Multipliers */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              {/* Play / Pause / Restart / Skip */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPlaying(prev => !prev)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold text-xs transition-all shadow-sm ${
                    isPlaying
                      ? 'bg-[#0B2340] hover:bg-[#1E293B] text-white'
                      : 'bg-[#0754A6] hover:bg-[#064487] text-white'
                  }`}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="w-4 h-4" /> Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" /> Play Simulation
                    </>
                  )}
                </button>

                <button
                  onClick={handleRestart}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#F3F5F8] hover:bg-[#E2E8F0] text-[#273444] font-medium text-xs transition-colors border border-[#CBD5E1]"
                  title="Restart Cycle"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Restart
                </button>

                <button
                  onClick={handleSkip45}
                  disabled={simProgress >= 1 || strokeAngle >= 360}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#F3F5F8] hover:bg-[#E2E8F0] text-[#273444] font-medium text-xs transition-colors border border-[#CBD5E1] disabled:opacity-40 disabled:cursor-not-allowed"
                  title="Advance stroke angle by +45° (stops at 100%)"
                >
                  <SkipForward className="w-3.5 h-3.5" /> Skip +45°
                </button>
              </div>

              {/* Interactive Stroke Percentage / Angle Slider & Precision Inputs */}
              <div className="flex-1 max-w-lg flex items-center gap-3 bg-[#F8FAFC] border border-[#CBD5E1] px-3 py-1.5 rounded-xl">
                {/* Clickable / Editable Percentage Badge */}
                {isEditingPercent ? (
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="1"
                    autoFocus
                    value={inputPercentValue}
                    onChange={(e) => setInputPercentValue(e.target.value)}
                    onBlur={handlePercentSubmit}
                    onKeyDown={(e) => e.key === 'Enter' && handlePercentSubmit()}
                    className="w-14 px-1 py-0.5 text-[11px] font-mono text-center font-bold text-[#0754A6] bg-white border border-[#0754A6] rounded focus:outline-none"
                    title="Press Enter or click away to commit percentage"
                  />
                ) : (
                  <button
                    onClick={() => {
                      setInputPercentValue(String(Math.min(100, Math.max(0, Math.round(simProgress * 100)))));
                      setIsEditingPercent(true);
                    }}
                    className="text-[11px] font-mono font-bold text-[#0B2340] px-1.5 py-0.5 rounded hover:bg-white hover:text-[#0754A6] border border-transparent hover:border-[#CBD5E1] transition-all cursor-pointer text-right min-w-[46px]"
                    title="Click to directly type stroke percentage (0-100%)"
                  >
                    {Math.min(100, Math.max(0, Math.round(simProgress * 100)))}%
                  </button>
                )}

                {/* Interactive Slider Track */}
                <div className="relative flex-1 flex items-center h-5">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="0.5"
                    value={Math.min(100, Math.max(0, simProgress * 100))}
                    onPointerDown={() => { isDraggingSliderRef.current = true; }}
                    onPointerUp={handleSliderCommit}
                    onMouseDown={() => { isDraggingSliderRef.current = true; }}
                    onTouchStart={() => { isDraggingSliderRef.current = true; }}
                    onChange={handleSliderChange}
                    onMouseUp={handleSliderCommit}
                    onTouchEnd={handleSliderCommit}
                    aria-label="Adjust Stroke Percentage / Angle"
                    className="w-full h-2 bg-[#E2E8F0] rounded-lg appearance-none cursor-ew-resize accent-[#0754A6] focus:outline-none focus:ring-2 focus:ring-[#0754A6]/30"
                  />
                </div>

                {/* Clickable / Editable Angle Badge */}
                {isEditingAngle ? (
                  <input
                    type="number"
                    min="0"
                    max="360"
                    step="1"
                    autoFocus
                    value={inputAngleValue}
                    onChange={(e) => setInputAngleValue(e.target.value)}
                    onBlur={handleAngleSubmit}
                    onKeyDown={(e) => e.key === 'Enter' && handleAngleSubmit()}
                    className="w-14 px-1 py-0.5 text-[11px] font-mono text-center font-bold text-[#0754A6] bg-white border border-[#0754A6] rounded focus:outline-none"
                    title="Press Enter or click away to commit angle"
                  />
                ) : (
                  <button
                    onClick={() => {
                      setInputAngleValue(String((strokeAngle >= 360 || simProgress >= 1) && strokeAngle > 0 ? 360 : Math.floor(((strokeAngle % 360) + 360) % 360)));
                      setIsEditingAngle(true);
                    }}
                    className="text-[11px] font-mono font-bold text-[#0754A6] px-1.5 py-0.5 rounded hover:bg-white border border-transparent hover:border-[#CBD5E1] transition-all cursor-pointer text-left min-w-[48px]"
                    title="Click to directly type stroke angle (0-360°)"
                  >
                    {(strokeAngle >= 360 || simProgress >= 1) && strokeAngle > 0 ? 360 : Math.floor(((strokeAngle % 360) + 360) % 360)}°
                  </button>
                )}
              </div>

              {/* Playback Speed Multipliers */}
              <div className="flex items-center gap-1 bg-[#F3F5F8] p-1 rounded-lg border border-[#E2E8F0]">
                <span className="text-[10px] font-semibold text-[#64748B] px-1.5 uppercase">Speed:</span>
                {([1, 2, 5] as const).map((spd) => (
                  <button
                    key={spd}
                    onClick={() => setPlaybackSpeed(spd)}
                    className={`px-2.5 py-1 text-xs font-mono font-semibold rounded transition-all ${
                      playbackSpeed === spd
                        ? 'bg-[#0754A6] text-white shadow-xs'
                        : 'text-[#64748B] hover:text-[#273444] hover:bg-white'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sequential Process Plan Flow Tracker */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2340] flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#0754A6]" />
                Manufacturing Process Flow (Exact In-House Sequence)
              </h3>
              <span className="text-xs text-[#64748B]">
                Total Operations: {totalOperations} Dies
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
              {currentPart.operations.map((op, idx) => {
                const isActive = idx === currentOpIndex;
                const isPast = idx < currentOpIndex;

                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setCurrentOpIndex(idx);
                      setSimProgress(0);
                      setStrokeAngle(0);
                    }}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-left shrink-0 transition-all ${
                      isActive
                        ? 'bg-[#0754A6]/10 border-[#0754A6] text-[#0754A6] ring-1 ring-[#0754A6]'
                        : isPast
                        ? 'bg-[#F8FAFC] border-[#CBD5E1] text-[#273444] hover:bg-white'
                        : 'bg-[#F3F5F8] border-[#E2E8F0] text-[#94A3B8] hover:bg-white'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[10px] font-bold ${
                        isActive
                          ? 'bg-[#0754A6] text-white'
                          : isPast
                          ? 'bg-[#10B981] text-white'
                          : 'bg-[#CBD5E1] text-[#64748B]'
                      }`}
                    >
                      {isPast ? '✓' : idx + 1}
                    </div>
                    <div>
                      <div className="text-xs font-bold leading-tight flex items-center gap-1.5">
                        {op.opCode}
                        <span className="text-[10px] font-normal opacity-75">
                          ({op.pressTonnage}T)
                        </span>
                      </div>
                      <div className="text-[11px] font-medium truncate max-w-[140px]">
                        {op.name}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Real-Time Telemetry & Part Specifications */}
        <div className="xl:col-span-4 flex flex-col gap-4">
          {/* Machine Telemetry Panel */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2340] flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-[#0754A6]" /> Machine Telemetry
              </h3>
            </div>

            {/* Telemetry Metric Cards */}
            <div className="grid grid-cols-2 gap-3">
              {/* Strokes Per Minute */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-2.5">
                <div className="text-[10px] text-[#64748B] uppercase font-bold">
                  Strokes / Min (SPM)
                </div>
                <div className="text-xl font-bold font-mono text-[#0B2340] mt-1">
                  {liveSpm.toFixed(0)} <span className="text-xs font-normal text-[#64748B]">SPM</span>
                </div>
                <div className="text-[10px] text-[#64748B] mt-0.5">
                  Line rating: {currentPart.devTypeCode === 'SL' ? '28 SPM max' : '20 SPM max'}
                </div>
              </div>

              {/* Operating Temperature */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-2.5">
                <div className="text-[10px] text-[#64748B] uppercase font-bold">
                  Die Bed Temp
                </div>
                <div className="text-xl font-bold font-mono text-[#0B2340] mt-1">
                  {operatingTempC} <span className="text-xs font-normal text-[#64748B]">°C</span>
                </div>
                <div className="text-[10px] text-[#059669] mt-0.5">
                  Thermal state: Normal
                </div>
              </div>

              {/* Press Hydraulic Pressure */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-2.5">
                <div className="text-[10px] text-[#64748B] uppercase font-bold">
                  Press Pressure
                </div>
                <div className="text-xl font-bold font-mono text-[#0754A6] mt-1">
                  {pressPressureBar.toFixed(1)} <span className="text-xs font-normal text-[#64748B]">bar</span>
                </div>
                <div className="text-[10px] text-[#64748B] mt-0.5">
                  Peak at BDC impact
                </div>
              </div>

              {/* Ram Stroke Angle */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-2.5">
                <div className="text-[10px] text-[#64748B] uppercase font-bold">
                  Stroke Angle
                </div>
                <div className="text-xl font-bold font-mono text-[#0B2340] mt-1">
                  {(strokeAngle >= 360 || simProgress >= 1) && strokeAngle > 0 ? 360 : Math.floor(((strokeAngle % 360) + 360) % 360)} <span className="text-xs font-normal text-[#64748B]">deg</span>
                </div>
                <div className="text-[10px] text-[#64748B] mt-0.5">
                  {strokeAngle < 90
                    ? 'Approach Stroke'
                    : strokeAngle < 180
                    ? 'Forming / Impact'
                    : strokeAngle < 270
                    ? 'Return Stroke'
                    : 'Dwell at TDC'}
                </div>
              </div>

              {/* Press Ram Displacement */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-2.5">
                <div className="text-[10px] text-[#64748B] uppercase font-bold">
                  Ram Movement
                </div>
                <div className="text-xl font-bold font-mono text-[#0B2340] mt-1">
                  {ramDisplacementMm.toFixed(1)} <span className="text-xs font-normal text-[#64748B]">mm</span>
                </div>
                <div className="text-[10px] text-[#64748B] mt-0.5">
                  Total stroke: 350 mm
                </div>
              </div>

              {/* Active Tonnage Load */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-2.5">
                <div className="text-[10px] text-[#64748B] uppercase font-bold">
                  Press Line Force
                </div>
                <div className="text-xl font-bold font-mono text-[#0B2340] mt-1">
                  {currentOperation.pressTonnage} <span className="text-xs font-normal text-[#64748B]">Tons</span>
                </div>
                <div className="text-[10px] text-[#64748B] mt-0.5 truncate">
                  {currentOperation.pressLine}
                </div>
              </div>
            </div>
          </div>

          {/* Part Technical Specifications Card */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2340] flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-[#0754A6]" /> Part Technical Specifications
              </h3>
              <span className="text-xs font-mono text-[#64748B]">
                ID: #{currentPart.id}
              </span>
            </div>

            <div className="divide-y divide-[#F1F5F9] text-xs">
              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Complete Part Name</span>
                <span className="font-semibold text-[#0B2340] text-right max-w-[200px]">
                  {currentPart.name}
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Part Dimensions (L × W × H)</span>
                <span className="font-mono font-semibold text-[#0B2340]">
                  {currentPart.lengthMm !== null
                    ? `${currentPart.lengthMm} × ${currentPart.widthMm} × ${currentPart.heightMm} mm`
                    : 'Not Available'}
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Material Specification</span>
                <span className="font-semibold text-[#0B2340] text-right max-w-[200px]">
                  {currentPart.materialSpec}
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Development Line Type</span>
                <span className="font-semibold text-[#0754A6]">
                  {currentPart.devType} ({currentPart.devTypeCode})
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Die Tooling Type</span>
                <span className="font-semibold text-[#0B2340]">
                  {currentPart.diesType}
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Blanking Dies (BLK)</span>
                <span className="font-mono font-semibold text-[#0B2340]">
                  {currentPart.blankDiesCount} Die{currentPart.blankDiesCount !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Forming Dies (DIES)</span>
                <span className="font-mono font-semibold text-[#0B2340]">
                  {currentPart.formingDiesCount} Dies
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Total Process Stations (Σ)</span>
                <span className="font-mono font-bold text-[#0754A6]">
                  {currentPart.totalDiesCount} Stations
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Assigned Press Line</span>
                <span className="font-semibold text-[#0B2340]">
                  {currentPart.pressLineSummary}
                </span>
              </div>

              <div className="py-2 flex justify-between items-center">
                <span className="text-[#64748B]">Press Tonnage Range</span>
                <span className="font-mono font-bold text-[#0B2340]">
                  {currentPart.pressTonnageRange}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
