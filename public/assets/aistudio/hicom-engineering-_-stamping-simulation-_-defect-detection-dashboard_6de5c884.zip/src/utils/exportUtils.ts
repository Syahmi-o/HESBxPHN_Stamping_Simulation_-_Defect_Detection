/**
 * Export Utility for HICOM Engineering Inspection History
 * Supports Microsoft Excel (.xlsx) and CSV (.csv) formats with filtered subsets
 */

import * as XLSX from 'xlsx';
import { InspectionRecord } from '../data/defectCategories';

export function exportToCsv(records: InspectionRecord[], filename: string = 'HICOM_Inspection_History'): void {
  const headers = [
    'Record ID',
    'Timestamp',
    'Part ID',
    'Part Name',
    'Length (mm)',
    'Width (mm)',
    'Height (mm)',
    'Development Type',
    'Die Type',
    'Press Line',
    'Status',
    'Defect Category',
    'Defect Location',
    'Defect Description',
    'Severity (%)',
    'Confidence (%)',
    'Verdict',
    'Inspector',
    'Detection Engine'
  ];

  const rows = records.map(r => [
    `"${r.id}"`,
    `"${new Date(r.timestamp).toLocaleString()}"`,
    r.partId,
    `"${(r.partName || '').replace(/"/g, '""')}"`,
    r.partSize.lengthMm ?? 'N/A',
    r.partSize.widthMm ?? 'N/A',
    r.partSize.heightMm ?? 'N/A',
    `"${r.devType}"`,
    `"${r.diesType}"`,
    `"${r.pressLine}"`,
    `"${r.status}"`,
    `"${(r.defectCategory || 'None').replace(/"/g, '""')}"`,
    `"${(r.defectLocation || 'N/A').replace(/"/g, '""')}"`,
    `"${(r.defectDescription || '').replace(/"/g, '""')}"`,
    r.severityPercentage !== null ? r.severityPercentage.toFixed(1) : 'N/A',
    r.confidencePercentage.toFixed(1),
    `"${r.verdict}"`,
    `"${r.inspectorName}"`,
    `"${r.detectionEngine}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportToExcel(records: InspectionRecord[], filename: string = 'HICOM_Inspection_History'): void {
  const formattedData = records.map(r => ({
    'Record ID': r.id,
    'Timestamp': new Date(r.timestamp).toLocaleString(),
    'Part ID': r.partId,
    'Part Name': r.partName,
    'Length (mm)': r.partSize.lengthMm ?? 'Not Available',
    'Width (mm)': r.partSize.widthMm ?? 'Not Available',
    'Height (mm)': r.partSize.heightMm ?? 'Not Available',
    'Development Line': r.devType,
    'Tooling Die Type': r.diesType,
    'Press Line': r.pressLine,
    'Inspection Status': r.status,
    'Defect Category': r.defectCategory || 'None (Pass)',
    'Defect Location': r.defectLocation || 'N/A',
    'Defect Description': r.defectDescription || 'Conforms to specifications',
    'Severity (%)': r.severityPercentage !== null ? Number(r.severityPercentage.toFixed(1)) : 0,
    'Confidence (%)': Number(r.confidencePercentage.toFixed(1)),
    'Quality Verdict': r.verdict,
    'Inspector': r.inspectorName,
    'Detection Engine': r.detectionEngine
  }));

  const worksheet = XLSX.utils.json_to_sheet(formattedData);

  // Set column widths for readability
  worksheet['!cols'] = [
    { wch: 22 }, // Record ID
    { wch: 22 }, // Timestamp
    { wch: 8 },  // Part ID
    { wch: 45 }, // Part Name
    { wch: 14 }, // Length
    { wch: 14 }, // Width
    { wch: 14 }, // Height
    { wch: 18 }, // Dev Line
    { wch: 18 }, // Die Type
    { wch: 16 }, // Press Line
    { wch: 16 }, // Status
    { wch: 26 }, // Defect Category
    { wch: 30 }, // Defect Location
    { wch: 45 }, // Description
    { wch: 14 }, // Severity
    { wch: 16 }, // Confidence
    { wch: 16 }, // Verdict
    { wch: 22 }, // Inspector
    { wch: 30 }  // Engine
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Inspection Records');

  // Summary statistics sheet
  const total = records.length;
  const passed = records.filter(r => r.verdict === 'PASS').length;
  const rework = records.filter(r => r.verdict === 'REWORK').length;
  const failed = records.filter(r => r.verdict === 'FAIL').length;

  const summaryData = [
    { Metric: 'Company', Value: 'HICOM Engineering Sdn Bhd' },
    { Metric: 'Division', Value: 'Stamping Quality Assurance' },
    { Metric: 'Report Generated', Value: new Date().toLocaleString() },
    { Metric: 'Total Inspected Parts', Value: total },
    { Metric: 'Total Passed (PASS)', Value: `${passed} (${total ? ((passed/total)*100).toFixed(1) : 0}%)` },
    { Metric: 'Total Rework (REWORK)', Value: `${rework} (${total ? ((rework/total)*100).toFixed(1) : 0}%)` },
    { Metric: 'Total Failed (FAIL)', Value: `${failed} (${total ? ((failed/total)*100).toFixed(1) : 0}%)` },
  ];
  const summarySheet = XLSX.utils.json_to_sheet(summaryData);
  summarySheet['!cols'] = [{ wch: 25 }, { wch: 35 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'QA Summary');

  XLSX.writeFile(workbook, `${filename}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

/**
 * Generates a formal textual QA Quality Inspection Certificate & Engineering Report
 */
export function generateInspectionReportText(record: InspectionRecord): string {
  const lineDivider = "================================================================================";
  const subDivider = "--------------------------------------------------------------------------------";

  return `${lineDivider}
HICOM ENGINEERING SDN BHD - QUALITY ASSURANCE & DEFECT INSPECTION REPORT
Automotive Stamping Division // Process Quality Engineering System
${lineDivider}

REPORT IDENTIFIER:    ${record.id}
INSPECTION TIMESTAMP: ${new Date(record.timestamp).toUTCString()}
INSPECTION OFFICER:   ${record.inspectorName}
DETECTION ENGINE:     ${record.detectionEngine}

${subDivider}
1. AUTOMOTIVE PART IDENTIFICATION & SPECIFICATIONS
${subDivider}
Part Catalog Number:  #${record.partId}
Complete Part Name:   ${record.partName}
Part Dimensions:      ${record.partSize.formatted}
  - Length (L):       ${record.partSize.lengthMm !== null ? `${record.partSize.lengthMm} mm` : 'Not Available'}
  - Width (W):        ${record.partSize.widthMm !== null ? `${record.partSize.widthMm} mm` : 'Not Available'}
  - Height (H):       ${record.partSize.heightMm !== null ? `${record.partSize.heightMm} mm` : 'Not Available'}
Development Line:     ${record.devType}
Tooling Die Type:     ${record.diesType}
Press Line Summary:   ${record.pressLine}

${subDivider}
2. AUTOMATED OPTICAL & SURFACE DEFECT ANALYSIS
${subDivider}
Inspection Status:    ${record.status === 'OK' ? 'OK [CONFORMING / WITHIN SPEC]' : 'NG [DEFECTIVE / NON-CONFORMING]'}
Quality Verdict:      ${record.verdict}
Defect Classification:${record.defectCategory || 'None Detected (Nominal Conformance)'}
Defect ID Code:       ${record.defectCategoryId ? record.defectCategoryId.toUpperCase() : 'N/A'}
Defect Severity:      ${record.severityPercentage !== null ? `${record.severityPercentage.toFixed(1)}%` : '0.0%'}
Inspection Confidence:${record.confidencePercentage.toFixed(1)}%

Defect Location:
  ${record.defectLocation || 'All surface inspection coordinates nominal.'}

Detailed Engineering Description:
  ${record.defectDescription || 'Part surface topography and cut boundaries conform to standard tolerances.'}

${record.reworkActionNotes ? `Authorized Rework Disposition:
  ${record.reworkActionNotes}
` : ''}
${record.boundingBox ? `Optical Bounding Coordinates:
  X: ${record.boundingBox.x}% | Y: ${record.boundingBox.y}% | Width: ${record.boundingBox.width}% | Height: ${record.boundingBox.height}%
  Annotation: [${record.boundingBox.label}]
` : ''}

${subDivider}
3. FINAL QUALITY DISPOSITION & SIGN-OFF
${subDivider}
Verdict Determination: ${record.verdict === 'PASS' ? 'APPROVED FOR NEXT MANUFACTURING STAGE / FINAL ASSEMBLY' : record.verdict === 'REWORK' ? 'ROUTED TO OFFLINE REWORK BENCH FOR REMEDIAL DRESSING' : 'REJECTED - SCRAP DISPOSITION (CRITICAL NON-CONFORMANCE)'}

Signed: ____________________________________
        ${record.inspectorName}
        HICOM Engineering Sdn Bhd QA Division
${lineDivider}
`;
}

export function downloadInspectionReport(record: InspectionRecord): void {
  const text = generateInspectionReportText(record);
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${record.id}_QA_REPORT.txt`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
