import test from 'node:test';
import assert from 'node:assert/strict';
import { STAMPING_PARTS, expandOperationName } from '../src/data/partsData.ts';
import {
  DEFECT_CATEGORIES,
  calculateInspectionVerdict
} from '../src/data/defectCategories.ts';

test('Stamping Parts Catalog contains all 43 specified parts', () => {
  assert.equal(STAMPING_PARTS.length, 43, 'Should have exactly 43 parts from the Excel Part List');

  // Verify part #1
  const part1 = STAMPING_PARTS[0];
  assert.equal(part1.id, 1);
  assert.equal(part1.codeName, 'PATCH FRONT FLOOR');
  assert.equal(part1.lengthMm, 610);
  assert.equal(part1.widthMm, 155);
  assert.equal(part1.heightMm, 114);
  assert.equal(part1.devTypeCode, 'ML');
  assert.equal(part1.diesTypeCode, 'CAST');
  assert.equal(part1.operations.length, 5);

  // Check last part #43
  const part43 = STAMPING_PARTS[42];
  assert.equal(part43.id, 43);
  assert.equal(part43.codeName, 'PLATE STRUT HOUSE RH');
  assert.equal(part43.lengthMm, 147);
  assert.equal(part43.widthMm, 128);
  assert.equal(part43.heightMm, 73);
});

test('Operation Name expansion accurately identifies manufacturing processes', () => {
  const blankExp = expandOperationName('BLANK');
  assert.equal(blankExp.action, 'blank');
  assert.ok(blankExp.fullName.includes('Blanking'));

  const drawExp = expandOperationName('DRAW');
  assert.equal(drawExp.action, 'draw');
  assert.ok(drawExp.fullName.includes('Drawing'));

  const trimExp = expandOperationName('TRIM, PIE');
  assert.equal(trimExp.action, 'trim');
  assert.ok(trimExp.fullName.includes('Trimming'));

  const restrikeExp = expandOperationName('RESTRIKE');
  assert.equal(restrikeExp.action, 'restrike');
  assert.ok(restrikeExp.fullName.includes('Restriking'));
});

test('Defect Categories contains all 15 automotive stamping categories', () => {
  assert.equal(DEFECT_CATEGORIES.length, 15, 'Should support exactly 15 standard defect categories');

  const burr = DEFECT_CATEGORIES.find(d => d.id === 'burr');
  assert.ok(burr, 'Burr defect category exists');
  assert.equal(burr?.code, 'DEF-01');

  const crack = DEFECT_CATEGORIES.find(d => d.id === 'crack');
  assert.ok(crack, 'Crack defect category exists');

  const splitting = DEFECT_CATEGORIES.find(d => d.id === 'splitting_tearing');
  assert.ok(splitting, 'Splitting/Tearing defect category exists');
});

test('Quality Verdict calculation applies defined engineering thresholds', () => {
  // Case 1: OK part should always yield PASS
  const passVerdict = calculateInspectionVerdict('OK', null, 0);
  assert.equal(passVerdict.verdict, 'PASS');

  // Case 2: Burr at 25% severity (reworkable)
  const reworkBurr = calculateInspectionVerdict('NG', 'burr', 25);
  assert.equal(reworkBurr.verdict, 'REWORK');

  // Case 3: Burr at 80% severity (excessive)
  const failBurr = calculateInspectionVerdict('NG', 'burr', 80);
  assert.equal(failBurr.verdict, 'FAIL');

  // Case 4: Splitting or Tearing is unconditional FAIL
  const failSplit = calculateInspectionVerdict('NG', 'splitting_tearing', 15);
  assert.equal(failSplit.verdict, 'FAIL');

  // Case 5: Crack > 20% is unconditional safety FAIL
  const failCrack = calculateInspectionVerdict('NG', 'crack', 25);
  assert.equal(failCrack.verdict, 'FAIL');
});
